const express = require('express');
const puppeteer = require('puppeteer');
const path = require('node:path');

const FLAG = process.env.FLAG || 'SK-CERT{fake_flag_for_handout}';
const CHALLENGE_URL = process.env.CHALLENGE_URL || 'http://challenge:4173';
const BOT_HOST = process.env.BOT_HOST || '0.0.0.0';
const BOT_PORT = Number(process.env.BOT_PORT || 3000);
const MAX_CONCURRENT = Number(process.env.MAX_CONCURRENT || 10);

let activeVisits = 0;

function randomSuffix(length = 8) {
  const alphabet = 'abcdefghijklmnopqrstuvwxyz0123456789';
  return Array.from({ length }, () => alphabet[Math.floor(Math.random() * alphabet.length)]).join('');
}

async function waitCellDone(page, cellIndex, timeoutMs = 120000) {
  await page.waitForFunction(
    (idx) => {
      const cell = document.querySelectorAll('.cell')[idx];
      return !!cell && !cell.classList.contains('running');
    },
    { timeout: timeoutMs },
    cellIndex
  );
}

async function clickButtonByExactText(page, text) {
  const clicked = await page.$$eval(
    'button',
    (buttons, expectedText) => {
      const target = buttons.find((button) => button.textContent?.trim() === expectedText);
      if (!target) return false;
      target.click();
      return true;
    },
    text
  );

  if (!clicked) {
    throw new Error(`button not found: ${text}`);
  }
}

async function setInputValue(page, selector, value) {
  await page.$eval(
    selector,
    (input, nextValue) => {
      input.value = nextValue;
      input.dispatchEvent(new Event('input', { bubbles: true }));
      input.dispatchEvent(new Event('change', { bubbles: true }));
    },
    value
  );
}

async function registerAndLogin(page, username, password) {
  const base = CHALLENGE_URL.replace(/\/$/, '');
  const authUrl = `${base}/auth/?mode=register&return=${encodeURIComponent(base)}`;

  await page.goto(authUrl, { waitUntil: 'domcontentloaded', timeout: 20000 });
  await setInputValue(page, 'input[autocomplete="username"]', username);
  await setInputValue(page, 'input[type="password"]', password);
  await page.click('#auth-page-submit');
  await page.waitForFunction(() => !window.location.pathname.startsWith('/auth'), { timeout: 30000 });
}

async function runAndSaveFlagCell(page, flagValue) {
  await clickButtonByExactText(page, '+ Cell');

  const cellIndex = await page.$$eval('.cell', (cells) => cells.length - 1);
  const source = `print(${JSON.stringify(flagValue)})`;

  await page.$$eval(
    '.cell .cell-editor',
    (editors, nextSource) => {
      const editor = editors[editors.length - 1];
      if (!editor) return;
      editor.value = nextSource;
      editor.dispatchEvent(new Event('input', { bubbles: true }));
      editor.dispatchEvent(new Event('change', { bubbles: true }));
    },
    source
  );

  await page.$$eval('.cell .run-btn', (buttons) => {
    const runButton = buttons[buttons.length - 1];
    if (runButton) runButton.click();
  });

  await waitCellDone(page, cellIndex);

  await clickButtonByExactText(page, 'Save');
  await page.waitForSelector('#save-submit-btn', { timeout: 10000 });
  await page.$eval('#save-submit-btn', submitBtn => submitBtn.click());
}

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.get('/health', (req, res) => {
  res.sendStatus(200);
});

app.post('/visit', async (req, res) => {
  const { url } = req.body || {};

  if (!url || typeof url !== 'string') {
    return res.status(400).json({ error: 'missing url' });
  }

  let parsedUrl;
  try {
    parsedUrl = new URL(url);
  } catch {
    return res.status(400).json({ error: 'invalid url' });
  }

  if (parsedUrl.protocol !== 'http:' && parsedUrl.protocol !== 'https:') {
    return res.status(400).json({ error: 'url must be http or https' });
  }

  if (activeVisits >= MAX_CONCURRENT) {
    return res.status(429).json({ error: 'too many concurrent visits' });
  }

  activeVisits += 1;

  let browser;
  try {
    browser = await puppeteer.launch({
      headless: true,
      executablePath: process.env.PUPPETEER_EXECUTABLE_PATH || '/usr/bin/chromium',
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-gpu'
      ]
    });

    const firstPage = await browser.newPage();
    await firstPage.goto(url, { timeout: 10000, waitUntil: 'networkidle2' });
    await new Promise((resolve) => setTimeout(resolve, 3000));
    await firstPage.close();

    const secondPage = await browser.newPage();
    const username = `ctf_${randomSuffix()}`;
    const password = 'ctfpass123';

    await registerAndLogin(secondPage, username, password);
    await runAndSaveFlagCell(secondPage, FLAG);

    await new Promise((resolve) => setTimeout(resolve, 1000));
    await secondPage.close();

    return res.json({ status: 'visited' });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'unknown error';
    console.error('visit error:', message);
    return res.status(500).json({ error: 'visit failed' });
  } finally {
    if (browser) {
      try {
        await browser.close();
      } catch {
        // ignore close errors
      }
    }

    activeVisits -= 1;
  }
});


app.listen(BOT_PORT, BOT_HOST, () => {
  console.log(`bot listening on ${BOT_HOST}:${BOT_PORT}`);
});


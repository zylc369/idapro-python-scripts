<script>
  import NotebookApp from '$lib/NotebookApp.svelte';
</script>

<svelte:head>
  <title>yipiii</title>
</svelte:head>

<NotebookApp allowUrlImport={false} />

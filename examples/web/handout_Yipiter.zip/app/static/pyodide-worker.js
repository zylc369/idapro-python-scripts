/* pyodide-worker.js – runs in a Web Worker */

const PYODIDE_VERSION = '0.27.3';
const PYODIDE_CDN = `https://cdn.jsdelivr.net/pyodide/v${PYODIDE_VERSION}/full/`;

importScripts(`${PYODIDE_CDN}pyodide.js`);

let pyodide = null;
let execCounter = 0;
let initialised = false;
let activeCellId = null;
let lastCellId = null;

/* ── post helpers ─────────────────────────────────────────── */
const post = (msg) => self.postMessage(msg);

/* ── Python bootstrap injected once after load ────────────── */
const BOOTSTRAP_PY = `
import sys, io, base64, builtins, traceback, json
import ast, inspect

# ── stdout / stderr capture ────────────────────────────────
class _YipStream:
    def __init__(self, name):
        self._n = name
    def write(self, text):
        if text:
            import js as _js
            _js._yip_post(json.dumps({'type': 'stream', 'name': self._n, 'text': text}))
    def flush(self): pass
    def isatty(self): return False
    def fileno(self): raise io.UnsupportedOperation('no fileno')

sys.stdout = _YipStream('stdout')
sys.stderr = _YipStream('stderr')

# ── display system ─────────────────────────────────────────
def _yip_send(mime_bundle):
    import js as _js
    _js._yip_post(json.dumps({'type': 'display_data', 'data': mime_bundle}))

def _display_obj(obj):
    # matplotlib Figure – handled before all MIME probing
    try:
        import matplotlib
        from matplotlib.figure import Figure
        if isinstance(obj, Figure):
            buf = io.BytesIO()
            obj.savefig(buf, format='png', bbox_inches='tight', dpi=150)
            buf.seek(0)
            _yip_send({'image/png': base64.b64encode(buf.read()).decode()})
            return
    except ImportError:
        pass

    # _repr_mimebundle_() – the canonical IPython rich-output protocol.
    # IPython.display.SVG / HTML / Image / DataFrame etc. all implement this.
    # It returns a dict like {'image/svg+xml': '...', 'text/plain': '...'}
    # We prefer the richest MIME we can render, in priority order.
    if hasattr(obj, '_repr_mimebundle_'):
        try:
            bundle = obj._repr_mimebundle_(include=set(), exclude=set())
        except TypeError:
            try:
                bundle = obj._repr_mimebundle_()
            except Exception:
                bundle = None
        if bundle:
            for mime in ('image/png','image/svg+xml','text/html',
                         'text/markdown','text/latex','text/plain'):
                if mime in bundle and bundle[mime] is not None:
                    val = bundle[mime]
                    if mime == 'image/png' and isinstance(val, (bytes, bytearray)):
                        val = base64.b64encode(val).decode()
                    _yip_send({mime: val})
                    return

    # Individual repr methods – for objects that only implement some of them.
    for attr, mime in [
        ('_repr_html_',    'text/html'),
        ('_repr_svg_',     'image/svg+xml'),
        ('_repr_latex_',   'text/latex'),
        ('_repr_markdown_','text/markdown'),
    ]:
        if hasattr(obj, attr):
            try:
                val = getattr(obj, attr)()
            except Exception:
                val = None
            if val is not None:
                _yip_send({mime: val})
                return

    if hasattr(obj, '_repr_png_'):
        try:
            raw = obj._repr_png_()
        except Exception:
            raw = None
        if raw is not None:
            data = base64.b64encode(raw).decode() if isinstance(raw, (bytes, bytearray)) else raw
            _yip_send({'image/png': data})
            return

    # plain text fallback
    _yip_send({'text/plain': repr(obj)})

builtins.display = _display_obj

# ── displayhook for last-expression value ──────────────────
def _yip_displayhook(value):
    if value is None:
        return
    builtins._ = value
    _display_obj(value)

sys.displayhook = _yip_displayhook

async def _yip_exec_cell(code: str):
  """Execute a notebook cell with Jupyter-like semantics.

  - supports top-level await
  - displays final expression result
  """
  tree = ast.parse(code, mode='exec')

  if tree.body and isinstance(tree.body[-1], ast.Expr):
    prefix = ast.Module(body=tree.body[:-1], type_ignores=[])
    prefix_code = compile(prefix, '<cell>', 'exec', flags=ast.PyCF_ALLOW_TOP_LEVEL_AWAIT)
    prefix_result = eval(prefix_code, globals(), globals())
    if inspect.isawaitable(prefix_result):
      await prefix_result

    expr = ast.Expression(tree.body[-1].value)
    expr_code = compile(expr, '<cell>', 'eval', flags=ast.PyCF_ALLOW_TOP_LEVEL_AWAIT)
    value = eval(expr_code, globals(), globals())
    if inspect.isawaitable(value):
      value = await value
    _yip_displayhook(value)
    return

  full_code = compile(tree, '<cell>', 'exec', flags=ast.PyCF_ALLOW_TOP_LEVEL_AWAIT)
  full_result = eval(full_code, globals(), globals())
  if inspect.isawaitable(full_result):
    await full_result

# ── matplotlib plt.show() patch ────────────────────────────
def _patch_matplotlib():
    try:
        import matplotlib
        matplotlib.use('agg')
        import matplotlib.pyplot as plt

        def _yip_show(*a, **kw):
            import matplotlib.pyplot as _plt
            for n in _plt.get_fignums():
                fig = _plt.figure(n)
                buf = io.BytesIO()
                fig.savefig(buf, format='png', bbox_inches='tight', dpi=150)
                buf.seek(0)
                _yip_send({'image/png': base64.b64encode(buf.read()).decode()})
            _plt.close('all')

        plt.show = _yip_show
    except Exception:
        pass

_patch_matplotlib()

# ── convenience display helpers (IPython-compatible) ──────
class _HtmlRepr:
    """Wrap HTML strings so display() renders them as HTML."""
    def __init__(self, data): self._data = data
    def _repr_html_(self): return self._data
    def __repr__(self): return self._data

class _SvgRepr:
    def __init__(self, data): self._data = data
    def _repr_svg_(self): return self._data
    def __repr__(self): return self._data

class _ImageRepr:
    """Wrap base64 or bytes PNG so display() renders as image."""
    def __init__(self, data=None, url=None, filename=None, format='png'):
        import base64 as _b64
        if isinstance(data, (bytes, bytearray)):
            self._b64 = _b64.b64encode(data).decode()
        elif isinstance(data, str):
            self._b64 = data
        else:
            self._b64 = None
        self._url = url
        self._format = format
    def _repr_png_(self):
        return self._b64
    def _repr_html_(self):
        if self._b64:
            return f'<img src="data:image/{self._format};base64,{self._b64}">'
        if self._url:
            return f'<img src="{self._url}">'
        return None
    def __repr__(self): return '<Image>'

# Provide a simple HTML/SVG/Image in builtins namespace for convenience
builtins.HTML  = _HtmlRepr
builtins.SVG   = _SvgRepr
builtins.Image = _ImageRepr

def _yip_reinstall_hooks():
    """Re-install all yipiii display hooks.
    Called after every loadPackagesFromImports so that packages like
    IPython that override builtins.display / sys.displayhook on import
    cannot silently break our output pipeline.
    """
    builtins.display       = _display_obj
    builtins.HTML          = _HtmlRepr
    builtins.SVG           = _SvgRepr
    builtins.Image         = _ImageRepr
    sys.displayhook        = _yip_displayhook
    sys.stdout             = _YipStream('stdout')
    sys.stderr             = _YipStream('stderr')
    _patch_matplotlib()
    # Patch IPython.display.display if IPython is already loaded,
    # so from IPython.display import display in user code gets our version.
    try:
        import importlib as _il
        _ipy_display = _il.import_module('IPython.display')
        def _wrapped_ipy_display(*objs, **kwargs):
            for obj in objs:
                _display_obj(obj)
        _ipy_display.display = _wrapped_ipy_display
        # Also patch IPython.core.display.display for good measure
        _ipy_core = _il.import_module('IPython.core.display')
        _ipy_core.display = _wrapped_ipy_display
    except Exception:
        pass

# Run once at startup
_yip_reinstall_hooks()

print("\\x1b[32m✓ yipiii kernel ready\\x1b[0m")
`;

/* ── initialise pyodide ───────────────────────────────────── */
async function init() {
  post({ type: 'status', status: 'loading', message: 'Fetching Pyodide…' });

  pyodide = await loadPyodide({ indexURL: PYODIDE_CDN });

  // Expose bridge on worker global so Python's `js` module can call it directly.
  // In a Web Worker, globalThis === self, and Pyodide's `js` module reflects globalThis.
  self._yip_post = (jsonStr) => {
    try {
      const msg = JSON.parse(jsonStr);
      post({ type: 'kernel_msg', payload: { ...msg, cellId: activeCellId ?? lastCellId } });
    } catch (e) {
      console.warn('[yipiii worker] bad JSON from Python:', jsonStr, e);
    }
  };

  post({ type: 'status', status: 'loading', message: 'Running bootstrap…' });

  try {
    await pyodide.runPythonAsync(BOOTSTRAP_PY);
  } catch (e) {
    post({ type: 'status', status: 'error', message: String(e) });
    return;
  }

  initialised = true;
  post({ type: 'status', status: 'ready', message: 'Kernel ready' });
}

/* ── execute a cell ───────────────────────────────────────── */
async function execute({ cellId, code }) {
  if (!initialised) {
    post({ type: 'execute_error', cellId, ename: 'KernelError', evalue: 'Kernel not ready', traceback: [] });
    return;
  }

  execCounter += 1;
  const execCount = execCounter;
  post({ type: 'execute_input', cellId, execCount });
  activeCellId = cellId;
  lastCellId = cellId;

  // Redirect any matplotlib show after import
  const prelude = `
import sys as _sys, io as _io
try:
    import matplotlib.pyplot as _plt
    _plt.close('all')
except Exception:
    pass
`;
  try {
    pyodide.runPython(prelude);
  } catch (_) { /* ignore */ }

  try {
    // auto-load any Pyodide-bundled packages the code imports
    await pyodide.loadPackagesFromImports(code, {
      messageCallback: (msg) => post({ type: 'status', status: 'busy', message: msg }),
      errorCallback:   (msg) => console.warn('[pyodide pkg]', msg),
    });
    // Re-install display hooks after package loading; packages like IPython
    // may override builtins.display or sys.displayhook on import.
    pyodide.runPython('_yip_reinstall_hooks()');
    const execCell = pyodide.globals.get('_yip_exec_cell');
    await execCell(code);
    execCell.destroy();
    post({ type: 'execute_result', cellId, execCount });
  } catch (err) {
    // Format traceback
    let ename = 'Error', evalue = String(err), tb = [];
    try {
      const tbStr = pyodide.runPython(`
import traceback as _tb, sys as _sys
_sys.last_exc = _sys.exc_info()[1] if _sys.exc_info()[1] else None
_tb.format_exc()
`);
      tb = [tbStr];
      // parse name/value from first line
      const lines = tbStr.trim().split('\n');
      const last = lines[lines.length - 1];
      const m = last.match(/^(\w+(?:\.\w+)*):\s*(.*)/);
      if (m) { ename = m[1]; evalue = m[2]; }
    } catch (_) {}
    post({ type: 'execute_error', cellId, execCount, ename, evalue, traceback: tb });
  } finally {
    activeCellId = null;
  }
}

/* ── restart ──────────────────────────────────────────────── */
async function restart() {
  initialised = false;
  execCounter = 0;
  pyodide = null;
  await init();
}

/* ── message router ───────────────────────────────────────── */
self.onmessage = async ({ data }) => {
  switch (data.type) {
    case 'init':    await init();             break;
    case 'execute': await execute(data);      break;
    case 'restart': await restart();          break;
  }
};
